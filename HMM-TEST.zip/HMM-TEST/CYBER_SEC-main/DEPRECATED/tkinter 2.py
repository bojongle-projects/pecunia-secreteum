from ast import main
from cProfile import label, run


from email import charset
from email import encoders
from glob import glob
from lib2to3.pgen2.token import OP
from logging import PlaceHolder
from operator import truediv
from pickle import GLOBAL
import tkinter 
import tkinter.ttk as ttk
from tkinter import *
          
from tkinter.font import BOLD
from turtle import onclick, onscreenclick, title
import tkinter as tkk
from tkinter.ttk import Button
from typing import ItemsView, final
import requests



#commands for the buttons



#def Pecunia_secretum_monero_Windows_install_script():
#def Pecunia_secretum_monero_arch_install_script():
#def Pecunia_secretum_monero_MacOS_install_script():

#pecunia_monero_installer



    



# Changing Label text


# Creation of Canvas

 

#run page

#creating 3rd level model




#creating first level functions

#create pecunia child instance button


# Creating a second Level




#Creating a second Level

   # Creation of Canvas



def create():
    global create
    win1 = Toplevel(MAIN_PAGE)







# Creating a second Level
def Op_DEM_PICK_VERSION():
 # Rename this
 win2 = Toplevel(Operation_Dementia_select_button)

def Pecunia_button():
    global Pecunia_button
    # Creating a second Level
    Pecunia = Toplevel()
    Pecunia.title("Pecunia Secretum") # Rename this
    Pecunia.geometry("400x400")
    # Changing Label text
    Pecunia = Label("In blockchain we trust")
    Pecunia = Label("latin for fuck the federal reserve")
    Pecuniabutton = Button(Pecunia, text="Select your version of Pecunia Secretum", command=Pecunia_install_page)
    # Creation of Canvas
    c=Canvas(Pecunia,height=800,width=800)
    c.pack()




def Pecunia_secretum_monero_debian_install_script():
    global Pecunia_install_page
    command=['bash', '-c', '. ~/.bash_profile; . Operation_dementia\Home-Made-Malware\Crypto miner bot\Install-XMR-Rig.sh']



def Kali_WSL_Windows_install_script():
    global Kali_WSL_Windows_install_script
 

















#creating 2nd level functions

MAIN_PAGE = Tk()
MAIN_PAGE.geometry("400x400")
MAIN_PAGE.title("Welcome to Home Made Malware")

title = Label(MAIN_PAGE, text="Welcome to Home Made Malware", font=("Arial", 20))




Operation_Dementia_button = Button(MAIN_PAGE, text="Operation Dementia", command = Op_DEM_PICK_VERSION)
Pecunia_button_MP = Button(MAIN_PAGE, text="Pecunia", command=Pecunia_button)
WSL_button_1 = Button(MAIN_PAGE, text="KALI WSL (Windows only)", command=W)

button5 = Button(MAIN_PAGE, text="button5")

button6 = Button(MAIN_PAGE, text="button1")

button7 = Button(MAIN_PAGE, text="button2")

button8 = Button(MAIN_PAGE, text="button3")

button9 = Button(MAIN_PAGE, text="button4")

button10 = Button(MAIN_PAGE, text="button5")



#packigng mainpage 



Operation_Dementia_button.pack()
Pecunia_button_MP.pack(pady=20)
WSL_button_1.pack(pady=20)

button7.pack(pady=20)
button6.pack(pady=20)
button5.pack(pady=20)
button8.pack(pady=20)
button9.pack(pady=20)
button10.pack(pady=20)


title.pack(pady=20)
MAIN_PAGE.mainloop()




# Creating a second Level
Operation_Dementia_Pick_Version_page = Tk()

Operation_Dementia_Pick_Version_page.geometry("400x400")
# Changing Label text
Operation_Dementia_Pick_Version_butt = Button(Operation_Dementia_Pick_Version_page, "Operation Dementia", command=Op_DEM_PICK_VERSION)
Operation_Dementia_Pick_Version_page_l1 = Label(Operation_Dementia_Pick_Version_page, text="In blockchain we trust")
Operation_Dementia_Pick_Version_page_l2 = Label(Operation_Dementia_Pick_Version_page, text="latin for fuck the federal reserve")
OP_DEM_button = Button(Operation_Dementia_Pick_Version_page, text="Select your version of Pecunia Secretum")
# Creation of Canvas


OP_DEM_C = Canvas(Operation_Dementia_Pick_Version_page, height=800,width=800)
OP_DEM_C.pack()
OP_DEM_C.mainloop()
    





Operation_Dementia_select_button = Tk()
Operation_Dementia_select_button.geometry("400x400")
Operation_Dementia_select_button = title("Operation Dementia") # Rename this



# Changing Label text
Operation_Dementia_H = Label("Ethically violating your privacy")
Operation_Dementia_SH = Label("The exact opposite of what your grandma would expect")
Operation_Dementia_select_button = Button(Operation_Dementia_select_button, text="Select your version of Operation Dementia", command=Op_DEM_PICK_VERSION)


Operation_Dementia_l1 = Label("Ethically violating your privacy")
Operation_Dementia_l2 = Label("The exact opposite of what your grandma would expect")
Operation_Dementia_l3 = Label("The only thing you need to know is that it is a fun way to fuck with your grandma")
Operation_Dementia_b1 = Button( text="Install Operation Dementia")

c=Canvas(height=800,width=800)

Operation_Dementia_H.pack()
Operation_Dementia_SH()
Operation_Dementia_select_button.pack()

Operation_Dementia_l1.pack()
Operation_Dementia_l2.pack()
Operation_Dementia_l3.pack()
Operation_Dementia_b1.pack()

c.pack()

c.mainloop()

Operation_Dementia_button.mainloop()













Pecunia_monero_installer = Tk()
Pecunia_monero_installer.geometry("400x400")
Pecunia_monero_installer = title("The Original Pecunia Secretum Experience")

Pecunia_monero_installer_l1 = Label("The Privacy centered edition of Pecunia Secretum", font=("Arial", 20))
Pecunia_monero_installer_L2 = Label("For those who like to fly under the radar, Pecunia Secretum is the perfect choice for you. Pecunia Secretum is a point and shoot cryptocurrency botnet orchestrator", font=("Arial", 20), pady=20)
Pecunia_monero_installer_deb = Button(Pecunia_monero_installer, text="Debian Based Distributions", command=Pecunia_secretum_monero_debian_install_script)
Pecunia_monero_installer_arch = Button(Pecunia_monero_installer, text="Arch Based Distributions", command=PlaceHolder)
Pecunia_monero_installer_win = Button(Pecunia_monero_installer, text="Windows", command=PlaceHolder)
Pecunia_monero_installer_mac = Button(Pecunia_monero_installer, text="MacOS", command=PlaceHolder)
Pecunia_monero_installer_l1.pack()
Pecunia_monero_installer_L2.pack()
Pecunia_monero_installer_deb.pack()
Pecunia_monero_installer_arch.pack()
Pecunia_monero_installer_win.pack()
Pecunia_monero_installer_mac.pack()



pmiC=Canvas(Pecunia_monero_installer,height=800,width=800)
pmiC.pack()

pmiC.mainloop()










 




   











Pecunia_install_page = Tk()


Pecunia_install_page.title("Pecunia Secretum Installer") 
Pecunia_install_page.geometry("400x400")
Pecunia_install_page = Label("latin for fuck the federal reserve")
Pecunia_install_page = Label("if they get a money printer... I mean its only fair.")
Pecunia_install_page = Label("In blockchain we trust")
Pecunia_install = Button(Pecunia_install_page, text="Install Pecunia Secretum for monero",command=Pecunia_monero_installer) 



c=Canvas(Pecunia_install_page,height=800, width = 800)
c.pack()







Pecunia_page = Tk()
#set page title
Pecunia_page.title("Pecunia Secretum: The Point and Shoot Crypto Miner Bot")
Pecuniabutton = Button(Pecunia_page, text="Pecunia Secretum", command=Pecunia_install_page)



Pecuniabutton.pack()

Pecunia_page.mainloop()







Pecunia_monero_installer.mainloop()











